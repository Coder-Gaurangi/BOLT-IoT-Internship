import Shop from './Components/Shop'

function App() {
  return(
    <div>
      <Shop />
    </div>
  );
}

export default App;